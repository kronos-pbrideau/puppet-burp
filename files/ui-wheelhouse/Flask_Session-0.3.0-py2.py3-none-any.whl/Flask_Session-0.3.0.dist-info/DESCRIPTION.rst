Flask-Session
-------------

Flask-Session is an extension for Flask that adds support for 
Server-side Session to your application.

Links
`````

* `development version
  <https://github.com/fengsp/flask-session/zipball/master#egg=Flask-dev>`_



