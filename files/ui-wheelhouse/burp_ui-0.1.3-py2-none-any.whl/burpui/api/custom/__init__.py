# -*- coding: utf8 -*-
"""
.. module:: burpui.api.custom
    :platform: Unix
    :synopsis: Burp-UI api custom module.

.. moduleauthor:: Ziirish <hi+burpui@ziirish.me>

"""
from .resource import Resource
