# THIS FILE IS AUTO-GENERATED. PLEASE DO NOT MODIFY# version file for ldap3
# generated on 2016-01-25 22:06:49.622498
# on system uname_result(system='Windows', node='GCNBHPW8', release='8.1', version='6.3.9600', machine='AMD64', processor='Intel64 Family 6 Model 58 Stepping 9, GenuineIntel')
# with Python 3.5.1 - ('v3.5.1:37a07cee5969', 'Dec  6 2015 01:54:25') - MSC v.1900 64 bit (AMD64)
#
__version__ = '1.0.4'
__author__ = 'Giovanni Cannata'
__email__ = 'cannatag@gmail.com'
__url__ = 'https://github.com/cannatag/ldap3'
__description__ = 'A strictly RFC 4510 conforming LDAP V3 pure Python client library. The same codebase works with Python 2, Python 3, PyPy, PyPy3 and Nuikta'
__status__ = '5 - Production/Stable'
__license__ = 'LGPL v3'
